/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arraylist;

import java.util.ArrayList;

/**
 *
 * @author Dell G15 Ryzen
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        ArrayList a = new ArrayList();
        a.add("Lenguaje");
        a.add(3);
        a.add("pera");
        a.add(23.5);
        System.out.println(a);
        
        /**ArrayList<String> names = new ArrayList<String>();
        names.add("una");
        names.add("dos");**/

    }

}
